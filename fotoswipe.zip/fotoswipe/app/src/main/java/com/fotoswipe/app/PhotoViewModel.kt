package com.fotoswipe.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PhotoViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ReviewStore(app)
    private val resolver get() = getApplication<Application>().contentResolver

    var folders by mutableStateOf<List<Folder>>(emptyList())
        private set
    var filters by mutableStateOf(Filters())
        private set
    var photos by mutableStateOf<List<Photo>>(emptyList())
        private set
    var index by mutableStateOf(0)
        private set
    var loading by mutableStateOf(false)
        private set

    /** Descartadas en esta sesión, pendientes de confirmar en el diálogo del sistema. */
    var discarded by mutableStateOf<List<Photo>>(emptyList())
        private set

    /** Historial para deshacer: par (foto, seConservó). */
    private val history = ArrayDeque<Pair<Photo, Boolean>>()

    val current: Photo? get() = photos.getOrNull(index)
    val next: Photo? get() = photos.getOrNull(index + 1)
    val canUndo: Boolean get() = history.isNotEmpty()
    val pendingBytes: Long get() = discarded.sumOf { it.size }

    fun loadFolders() {
        viewModelScope.launch {
            loading = true
            folders = withContext(Dispatchers.IO) { MediaRepository.loadFolders(resolver) }
            loading = false
        }
    }

    fun updateFilters(newFilters: Filters) {
        filters = newFilters
    }

    fun startSession() {
        viewModelScope.launch {
            loading = true
            val all = withContext(Dispatchers.IO) { MediaRepository.loadPhotos(resolver, filters) }
            val keptIds = store.kept
            photos = if (filters.skipReviewed) all.filterNot { keptIds.contains(it.id.toString()) } else all
            index = 0
            store.clearPending()
            discarded = emptyList()
            history.clear()
            loading = false
        }
    }

    fun keep() {
        val photo = current ?: return
        store.markKept(photo.id)
        history.addLast(photo to true)
        index++
    }

    fun discard() {
        val photo = current ?: return
        store.addPending(photo.id)
        discarded = discarded + photo
        history.addLast(photo to false)
        index++
    }

    fun undo() {
        val (photo, wasKept) = history.removeLastOrNull() ?: return
        if (wasKept) {
            store.unmarkKept(photo.id)
        } else {
            store.removePending(photo.id)
            discarded = discarded.filterNot { it.id == photo.id }
        }
        if (index > 0) index--
    }

    fun pendingUris(): List<Uri> = discarded.map { it.uri }

    /** Se llama cuando el usuario confirma el diálogo del sistema. */
    fun onTrashConfirmed() {
        val trashedIds = discarded.map { it.id }.toSet()
        store.clearPending()
        val removedBeforeIndex = photos.take(index).count { trashedIds.contains(it.id) }
        photos = photos.filterNot { trashedIds.contains(it.id) }
        index = (index - removedBeforeIndex).coerceAtLeast(0)
        discarded = emptyList()
        history.clear()
    }

    fun resetReviewed() {
        store.resetAll()
        startSession()
    }
}
