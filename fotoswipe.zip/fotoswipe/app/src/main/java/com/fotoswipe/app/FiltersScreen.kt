package com.fotoswipe.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FiltersScreen(vm: PhotoViewModel, onStart: () -> Unit) {
    val filters = vm.filters

    Scaffold(
        topBar = { TopAppBar(title = { Text("FotoSwipe") }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.padding(16.dp)) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !vm.loading
                    ) { Text("Empezar a revisar") }
                }
            }
        }
    ) { padding ->
        if (vm.loading && vm.folders.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text("Carpetas", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (filters.bucketIds.isEmpty()) "Ninguna seleccionada = todas"
                    else "${filters.bucketIds.size} seleccionadas",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
            }

            items(vm.folders) { folder ->
                val checked = filters.bucketIds.contains(folder.id)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val ids = if (checked) filters.bucketIds - folder.id
                            else filters.bucketIds + folder.id
                            vm.updateFilters(filters.copy(bucketIds = ids))
                        }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = checked, onCheckedChange = null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(folder.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "${folder.count} fotos · ${formatBytes(folder.bytes)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(Modifier.height(16.dp))
                Text("Formato", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                FlowRowSimple {
                    KNOWN_MIME_TYPES.forEach { (mime, label) ->
                        val selected = filters.mimeTypes.contains(mime)
                        FilterChip(
                            selected = selected,
                            onClick = {
                                val set = if (selected) filters.mimeTypes - mime
                                else filters.mimeTypes + mime
                                vm.updateFilters(filters.copy(mimeTypes = set))
                            },
                            label = { Text(label) },
                            modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Text("Orden", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                FlowRowSimple {
                    SortOrder.entries.forEach { order ->
                        FilterChip(
                            selected = filters.order == order,
                            onClick = { vm.updateFilters(filters.copy(order = order)) },
                            label = { Text(order.label) },
                            modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Text("Tamaño mínimo", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (filters.minSizeKb == 0) "Sin límite" else "Desde ${filters.minSizeKb} KB",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = filters.minSizeKb.toFloat(),
                    onValueChange = { vm.updateFilters(filters.copy(minSizeKb = it.toInt())) },
                    valueRange = 0f..5000f,
                    steps = 49
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            vm.updateFilters(filters.copy(skipReviewed = !filters.skipReviewed))
                        }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Switch(checked = filters.skipReviewed, onCheckedChange = null)
                    Spacer(Modifier.width(12.dp))
                    Text("Ocultar las que ya conservé", Modifier.weight(1f))
                }
                TextButton(onClick = { vm.resetReviewed() }) {
                    Text("Olvidar historial y revisarlo todo otra vez")
                }
                Spacer(Modifier.height(48.dp))
            }
        }
    }
}

/** Fila que envuelve el contenido en varias lineas. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRowSimple(content: @Composable () -> Unit) {
    FlowRow(modifier = Modifier.fillMaxWidth()) { content() }
}
