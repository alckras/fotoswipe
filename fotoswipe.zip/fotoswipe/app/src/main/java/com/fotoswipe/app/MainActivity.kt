package com.fotoswipe.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                }
            }
        }
    }
}

private val readPermissions: Array<String>
    get() = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

@Composable
fun AppRoot(vm: PhotoViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(
            readPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }
    var screen by remember { mutableStateOf(Screen.FILTERS) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        granted = result.values.all { it }
        if (granted) vm.loadFolders()
    }

    LaunchedEffect(granted) {
        if (granted) vm.loadFolders()
    }

    if (!granted) {
        PermissionScreen { permissionLauncher.launch(readPermissions) }
        return
    }

    when (screen) {
        Screen.FILTERS -> FiltersScreen(
            vm = vm,
            onStart = {
                vm.startSession()
                screen = Screen.SWIPE
            }
        )

        Screen.SWIPE -> SwipeScreen(
            vm = vm,
            onBack = { screen = Screen.FILTERS }
        )
    }
}

enum class Screen { FILTERS, SWIPE }

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "FotoSwipe necesita acceso a tus fotos y videos para poder mostrarlos y mandarlos a la papelera.",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("Conceder acceso") }
        Spacer(Modifier.height(16.dp))
        Text(
            "Si Android te ofrece \"seleccionar fotos\", elige permitir todas: la app necesita ver la galería completa para filtrar por carpetas.",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
