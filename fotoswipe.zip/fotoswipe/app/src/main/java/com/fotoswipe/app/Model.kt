package com.fotoswipe.app

import android.net.Uri

data class Photo(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val bucketId: String,
    val bucketName: String,
    val mimeType: String,
    val dateAdded: Long
)

data class Folder(
    val id: String,
    val name: String,
    val count: Int,
    val bytes: Long
)

enum class SortOrder(val label: String) {
    NEWEST("Más recientes"),
    OLDEST("Más antiguas"),
    LARGEST("Más pesadas"),
    RANDOM("Aleatorio")
}

data class Filters(
    val bucketIds: Set<String> = emptySet(),
    val mimeTypes: Set<String> = emptySet(),
    val minSizeKb: Int = 0,
    val order: SortOrder = SortOrder.NEWEST,
    val skipReviewed: Boolean = true
)

val KNOWN_MIME_TYPES = listOf(
    "image/jpeg" to "JPG",
    "image/png" to "PNG",
    "image/webp" to "WEBP",
    "image/gif" to "GIF",
    "image/heif" to "HEIF",
    "image/heic" to "HEIC"
)

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024) String.format("%.2f GB", mb / 1024.0)
    else if (mb >= 1) String.format("%.1f MB", mb)
    else String.format("%.0f KB", bytes / 1024.0)
}
