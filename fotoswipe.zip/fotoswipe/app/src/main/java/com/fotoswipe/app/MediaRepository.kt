package com.fotoswipe.app

import android.content.ContentResolver
import android.content.ContentUris
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore

object MediaRepository {

    /** Tabla unificada: ve imagenes y videos a la vez. */
    private val filesCollection: Uri =
        MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private val imagesCollection: Uri =
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private val videosCollection: Uri =
        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.DISPLAY_NAME,
        MediaStore.Files.FileColumns.SIZE,
        MediaStore.Files.FileColumns.BUCKET_ID,
        MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
        MediaStore.Files.FileColumns.MIME_TYPE,
        MediaStore.Files.FileColumns.DATE_ADDED,
        MediaStore.Files.FileColumns.MEDIA_TYPE
    )

    private val TYPE_IMAGE = MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
    private val TYPE_VIDEO = MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO

    private fun mediaTypeClause(includeVideos: Boolean): String =
        if (includeVideos) "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN ($TYPE_IMAGE,$TYPE_VIDEO)"
        else "${MediaStore.Files.FileColumns.MEDIA_TYPE} = $TYPE_IMAGE"

    /** Carpetas con su numero de archivos y peso total (imagenes y videos). */
    fun loadFolders(resolver: ContentResolver): List<Folder> {
        val map = LinkedHashMap<String, Triple<String, Int, Long>>()
        resolver.query(filesCollection, projection, mediaTypeClause(true), null, null)?.use { c ->
            val bucketIdCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_ID)
            val bucketNameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            while (c.moveToNext()) {
                val id = c.getString(bucketIdCol) ?: continue
                val name = c.getString(bucketNameCol) ?: "(sin nombre)"
                val size = c.getLong(sizeCol)
                val prev = map[id]
                map[id] = if (prev == null) Triple(name, 1, size)
                else Triple(prev.first, prev.second + 1, prev.third + size)
            }
        }
        return map.map { (id, v) -> Folder(id, v.first, v.second, v.third) }
            .sortedByDescending { it.bytes }
    }

    /** Archivos que cumplen los filtros indicados. */
    fun loadPhotos(resolver: ContentResolver, filters: Filters): List<Photo> {
        val where = mutableListOf(mediaTypeClause(filters.includeVideos))
        val args = mutableListOf<String>()

        if (filters.bucketIds.isNotEmpty()) {
            where += "${MediaStore.Files.FileColumns.BUCKET_ID} IN (${filters.bucketIds.joinToString(",") { "?" }})"
            args += filters.bucketIds
        }
        if (filters.mimeTypes.isNotEmpty()) {
            where += "${MediaStore.Files.FileColumns.MIME_TYPE} IN (${filters.mimeTypes.joinToString(",") { "?" }})"
            args += filters.mimeTypes
        }
        if (filters.minSizeKb > 0) {
            where += "${MediaStore.Files.FileColumns.SIZE} >= ?"
            args += (filters.minSizeKb * 1024L).toString()
        }

        val selection = where.joinToString(" AND ")
        val selectionArgs = if (args.isEmpty()) null else args.toTypedArray()

        val sortOrder = when (filters.order) {
            SortOrder.NEWEST -> "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
            SortOrder.OLDEST -> "${MediaStore.Files.FileColumns.DATE_ADDED} ASC"
            SortOrder.LARGEST -> "${MediaStore.Files.FileColumns.SIZE} DESC"
            SortOrder.RANDOM -> "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
        }

        val result = mutableListOf<Photo>()
        resolver.query(filesCollection, projection, selection, selectionArgs, sortOrder)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val bucketIdCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_ID)
            val bucketNameCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME)
            val mimeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
            val typeCol = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val isVideo = c.getInt(typeCol) == TYPE_VIDEO
                val base = if (isVideo) videosCollection else imagesCollection
                result += Photo(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    name = c.getString(nameCol) ?: "",
                    size = c.getLong(sizeCol),
                    bucketId = c.getString(bucketIdCol) ?: "",
                    bucketName = c.getString(bucketNameCol) ?: "(sin nombre)",
                    mimeType = c.getString(mimeCol) ?: "",
                    dateAdded = c.getLong(dateCol),
                    isVideo = isVideo
                )
            }
        }
        return if (filters.order == SortOrder.RANDOM) result.shuffled() else result
    }

    /**
     * Peticion de papelera POR LOTES. El sistema muestra UN solo dialogo
     * para toda la lista de URIs. Nunca llamar a esto por cada archivo.
     */
    fun trashRequest(resolver: ContentResolver, uris: List<Uri>): IntentSender =
        MediaStore.createTrashRequest(resolver, uris, true).intentSender
}
