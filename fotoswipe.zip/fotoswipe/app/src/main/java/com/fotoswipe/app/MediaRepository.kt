package com.fotoswipe.app

import android.content.ContentResolver
import android.content.ContentUris
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore

object MediaRepository {

    private val collection: Uri =
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.SIZE,
        MediaStore.Images.Media.BUCKET_ID,
        MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Images.Media.MIME_TYPE,
        MediaStore.Images.Media.DATE_ADDED
    )

    /** Lista de carpetas de la galería con su número de fotos y peso total. */
    fun loadFolders(resolver: ContentResolver): List<Folder> {
        val map = LinkedHashMap<String, Triple<String, Int, Long>>()
        resolver.query(collection, projection, null, null, null)?.use { c ->
            val bucketIdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val bucketNameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getString(bucketIdCol) ?: continue
                val name = c.getString(bucketNameCol) ?: "(sin nombre)"
                val size = c.getLong(sizeCol)
                val prev = map[id]
                map[id] = if (prev == null) Triple(name, 1, size)
                else Triple(prev.first, prev.second + 1, prev.third + size)
            }
        }
        return map.map { (id, v) -> Folder(id, v.first, v.second, v.third) }
            .sortedByDescending { it.bytes }
    }

    /** Fotos que cumplen los filtros indicados. */
    fun loadPhotos(resolver: ContentResolver, filters: Filters): List<Photo> {
        val where = mutableListOf<String>()
        val args = mutableListOf<String>()

        if (filters.bucketIds.isNotEmpty()) {
            where += "${MediaStore.Images.Media.BUCKET_ID} IN (${filters.bucketIds.joinToString(",") { "?" }})"
            args += filters.bucketIds
        }
        if (filters.mimeTypes.isNotEmpty()) {
            where += "${MediaStore.Images.Media.MIME_TYPE} IN (${filters.mimeTypes.joinToString(",") { "?" }})"
            args += filters.mimeTypes
        }
        if (filters.minSizeKb > 0) {
            where += "${MediaStore.Images.Media.SIZE} >= ?"
            args += (filters.minSizeKb * 1024L).toString()
        }

        val selection = if (where.isEmpty()) null else where.joinToString(" AND ")
        val selectionArgs = if (args.isEmpty()) null else args.toTypedArray()

        val sortOrder = when (filters.order) {
            SortOrder.NEWEST -> "${MediaStore.Images.Media.DATE_ADDED} DESC"
            SortOrder.OLDEST -> "${MediaStore.Images.Media.DATE_ADDED} ASC"
            SortOrder.LARGEST -> "${MediaStore.Images.Media.SIZE} DESC"
            SortOrder.RANDOM -> "${MediaStore.Images.Media.DATE_ADDED} DESC"
        }

        val result = mutableListOf<Photo>()
        resolver.query(collection, projection, selection, selectionArgs, sortOrder)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val bucketIdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val bucketNameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += Photo(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    name = c.getString(nameCol) ?: "",
                    size = c.getLong(sizeCol),
                    bucketId = c.getString(bucketIdCol) ?: "",
                    bucketName = c.getString(bucketNameCol) ?: "(sin nombre)",
                    mimeType = c.getString(mimeCol) ?: "",
                    dateAdded = c.getLong(dateCol)
                )
            }
        }
        return if (filters.order == SortOrder.RANDOM) result.shuffled() else result
    }

    /**
     * Petición de papelera POR LOTES. El sistema muestra UN solo diálogo
     * para toda la lista de URIs. Nunca llamar a esto por cada foto.
     */
    fun trashRequest(resolver: ContentResolver, uris: List<Uri>): IntentSender =
        MediaStore.createTrashRequest(resolver, uris, true).intentSender
}
