package com.fotoswipe.app

import android.content.Context

/**
 * Guarda qué fotos ya has revisado para no volver a enseñártelas,
 * y la cola de descartadas pendientes de mandar a la papelera.
 */
class ReviewStore(context: Context) {

    private val prefs = context.getSharedPreferences("fotoswipe", Context.MODE_PRIVATE)

    var kept: Set<String>
        get() = prefs.getStringSet(KEY_KEPT, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_KEPT, value).apply()

    var pending: Set<String>
        get() = prefs.getStringSet(KEY_PENDING, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_PENDING, value).apply()

    fun markKept(id: Long) {
        kept = kept + id.toString()
    }

    fun unmarkKept(id: Long) {
        kept = kept - id.toString()
    }

    fun addPending(id: Long) {
        pending = pending + id.toString()
    }

    fun removePending(id: Long) {
        pending = pending - id.toString()
    }

    fun clearPending() {
        pending = emptySet()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_KEPT = "kept_ids"
        private const val KEY_PENDING = "pending_ids"
    }
}
