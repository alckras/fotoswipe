package com.fotoswipe.app

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private const val FLUSH_EVERY = 40

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
fun SwipeScreen(vm: PhotoViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }

    // Un unico reproductor reutilizado para todas las tarjetas de video.
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
            volume = 0f
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    val currentItem = vm.current
    LaunchedEffect(currentItem?.id, currentItem?.isVideo) {
        if (currentItem != null && currentItem.isVideo) {
            player.setMediaItem(MediaItem.fromUri(currentItem.uri))
            player.prepare()
            player.play()
        } else {
            player.pause()
            player.clearMediaItems()
        }
    }

    val trashLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            vm.onTrashConfirmed()
        }
    }

    var askOnExit by remember { mutableStateOf(false) }

    fun tryBack() {
        if (vm.discarded.isNotEmpty()) askOnExit = true else onBack()
    }

    BackHandler { tryBack() }

    fun flushTrash() {
        val uris = vm.pendingUris()
        if (uris.isEmpty()) return
        val sender = MediaRepository.trashRequest(context.contentResolver, uris)
        trashLauncher.launch(IntentSenderRequest.Builder(sender).build())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("${vm.index} / ${vm.photos.size}", style = MaterialTheme.typography.titleMedium)
                        if (vm.discarded.isNotEmpty()) {
                            Text(
                                "${vm.discarded.size} a borrar · ${formatBytes(vm.pendingBytes)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { tryBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                        Icon(Icons.Default.Undo, contentDescription = "Deshacer")
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (vm.discarded.isNotEmpty()) {
                        Button(
                            onClick = { flushTrash() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError
                            )
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Vaciar: ${vm.discarded.size} archivos · ${formatBytes(vm.pendingBytes)}")
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { vm.discard() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Descartar")
                        }
                        Button(
                            onClick = { vm.keep() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Conservar")
                        }
                    }
                }
            }
        }
    ) { padding ->

        if (askOnExit) {
            AlertDialog(
                onDismissRequest = { askOnExit = false },
                title = { Text("Tienes ${vm.discarded.size} marcados sin borrar") },
                text = {
                    Text(
                        "Ocupan ${formatBytes(vm.pendingBytes)}. Si sales ahora se pierde la seleccion y no se borra nada."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        askOnExit = false
                        flushTrash()
                    }) { Text("Mandar a la papelera") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        askOnExit = false
                        onBack()
                    }) { Text("Salir sin borrar") }
                }
            )
        }

        val photo = vm.current

        if (vm.loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (photo == null) {
            FinishedPanel(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                pendingCount = vm.discarded.size,
                pendingBytes = vm.pendingBytes,
                onFlush = { flushTrash() },
                onBack = onBack
            )
            return@Scaffold
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {

            // Carta de debajo: la siguiente foto, para que no parpadee al pasar.
            vm.next?.let { nextPhoto ->
                AsyncImage(
                    model = nextPhoto.uri,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { scaleX = 0.95f; scaleY = 0.95f; alpha = 0.5f }
                        .clip(RoundedCornerShape(16.dp))
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                    .graphicsLayer { rotationZ = offsetX.value / 60f }
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
                    .pointerInput(photo.id) {
                        val threshold = size.width * 0.28f
                        detectDragGestures(
                            onDrag = { change, drag ->
                                change.consume()
                                scope.launch { offsetX.snapTo(offsetX.value + drag.x) }
                            },
                            onDragEnd = {
                                scope.launch {
                                    val value = offsetX.value
                                    when {
                                        value > threshold -> {
                                            offsetX.animateTo(size.width * 1.5f)
                                            vm.keep()
                                            offsetX.snapTo(0f)
                                        }
                                        value < -threshold -> {
                                            offsetX.animateTo(-size.width * 1.5f)
                                            vm.discard()
                                            offsetX.snapTo(0f)
                                            if (vm.discarded.size >= FLUSH_EVERY) flushTrash()
                                        }
                                        else -> offsetX.animateTo(0f)
                                    }
                                }
                            },
                            onDragCancel = {
                                scope.launch { offsetX.animateTo(0f) }
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                if (photo.isVideo) {
                    AndroidView(
                        factory = { ctx ->
                            (android.view.LayoutInflater.from(ctx)
                                .inflate(R.layout.video_card, null) as PlayerView)
                                .also { it.player = player }
                        },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    AsyncImage(
                        model = photo.uri,
                        contentDescription = photo.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Sellos de KEEP / DELETE según el arrastre.
                val alphaKeep = (offsetX.value / 300f).coerceIn(0f, 1f)
                val alphaDelete = (-offsetX.value / 300f).coerceIn(0f, 1f)

                if (alphaKeep > 0.02f) {
                    Stamp("CONSERVAR", Color(0xFF2E7D32), alphaKeep, Alignment.CenterStart)
                }
                if (alphaDelete > 0.02f) {
                    Stamp("BORRAR", Color(0xFFC62828), alphaDelete, Alignment.CenterEnd)
                }

                if (photo.isVideo) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                    ) {
                        Text(
                            "VÍDEO",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    photo.name,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    maxLines = 1
                )
                Text(
                    "${photo.bucketName} · ${formatBytes(photo.size)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun BoxScope.Stamp(text: String, color: Color, alpha: Float, alignment: Alignment) {
    Surface(
        color = color.copy(alpha = alpha * 0.85f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .align(alignment)
            .padding(24.dp)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            color = Color.White,
            style = MaterialTheme.typography.titleLarge
        )
    }
}

@Composable
private fun FinishedPanel(
    modifier: Modifier,
    pendingCount: Int,
    pendingBytes: Long,
    onFlush: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = modifier.padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (pendingCount > 0) {
            Text(
                "Has marcado $pendingCount fotos para borrar (${formatBytes(pendingBytes)}).",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Van a la papelera del sistema: se pueden recuperar durante 30 días.",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onFlush) { Text("Mandar a la papelera") }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onBack) { Text("Volver a los filtros") }
        } else {
            Text(
                "No queda nada por revisar con estos filtros.",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onBack) { Text("Cambiar filtros") }
        }
    }
}
