# FotoSwipe

App de Android para revisar fotos y videos de la galeria estilo Tinder: arrastra a la derecha para
conservar, a la izquierda para descartar. Lo descartado va a la **papelera del
sistema** (recuperable 30 dias), no se destruye.

## Como conseguir el APK sin instalar nada

1. Entra en https://github.com/new y crea un repositorio (puede ser privado).
2. En la pagina del repositorio vacio, pulsa **uploading an existing file**.
3. Descomprime este zip y arrastra **todo el contenido** (las carpetas `app`,
   `.github` y los ficheros `.gradle.kts` y `gradle.properties`) a la ventana
   del navegador. Importante: sube el contenido, no la carpeta `fotoswipe`
   entera, o las rutas quedaran mal.
4. Pulsa **Commit changes**.
5. Ve a la pestana **Actions**. Veras una ejecucion llamada "Build APK" en
   marcha. Tarda entre 3 y 6 minutos la primera vez.
6. Cuando termine con un tick verde, entra en la ejecucion y baja hasta
   **Artifacts**: descarga `FotoSwipe-debug-apk`.
7. Descomprime el zip que te baja: dentro esta `app-debug.apk`.
8. Pasalo al movil, abrelo y acepta instalar desde origenes desconocidos.

Si la ejecucion sale en rojo, abre el paso que fallo, copia el error y pasamelo.

## Requisitos del movil

Android 11 o superior (minSdk 30). Es la version desde la que existe la API de
papelera por lotes.

## Estructura

- `Model.kt` - tipos de datos y filtros
- `MediaRepository.kt` - consultas a MediaStore y peticion de papelera por lotes
- `ReviewStore.kt` - memoria de fotos ya revisadas y cola de pendientes
- `PhotoViewModel.kt` - estado de la sesion, deshacer, contadores
- `FiltersScreen.kt` - seleccion de carpetas, formatos, orden y tamano
- `SwipeScreen.kt` - la pila de cartas y los gestos

## Nota tecnica importante

El borrado se acumula y se confirma en lotes de 40 (constante `FLUSH_EVERY` en
`SwipeScreen.kt`). Android obliga a mostrar un dialogo del sistema por cada
peticion, asi que pedir foto a foto haria la app inservible.

## Videos

La app consulta la tabla unificada `MediaStore.Files` filtrando por
`MEDIA_TYPE IN (imagen, video)`, asi que ve tambien carpetas como
"WhatsApp Animated Gifs", cuyo contenido son en realidad ficheros MP4.
Las miniaturas de video las genera el `VideoFrameDecoder` de Coil.
El interruptor "Incluir videos" de la pantalla de filtros los deja fuera.
